<?php

//Redericionar para a pagina principal do sistema
header("location: ./app/controller/HomeController.php?action=home");
