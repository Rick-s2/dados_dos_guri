# Projeto-Integrador-Escoteiros

  Este projeto tem como objetivo principal, o controle de envios de tarefa requisitas pelos Escoteiros aos Lobinhos, como meio de suprir a grande demanda existente pelo Grupo de Escoteiros Guairacá - Foz do Iguaçu.
  
  O Sistema Web também ficará encarregado de registrar a presença dos Lobinhos, nos encontro realizados todo Sábado a tarde pelo grupo.

  Integrantes do grupo:

  -> Guillermo del Toro Trillo - 4° ano TDS - IFPR;
  -> Henry Gabriel Barros Szchaida - 4° ano TDS - IFPR;
  -> Marco Aurélio Dias Souza - 4° ano TDS - IFPR;
  -> Ricardo Augusto da Cruz Troche - 4° ano TDS - IFPR;


/*
CRIAR UPDATES CONTATO E ENDERECO
CRIAR INSERT CONTATO 
CRIAR CONEXAO ENTRE IDCONTATO, IDENDERECO COM O USUARIO
FAZER APARECER O STATUS NO LIST.PHP*/


PROXIMO PASSO:

ENCONTROS DA ALCATEIA
LISTAR USUÁRIOS DA ALCATEIA
CRIAR SELECT PARA SELECIONAR A ALCATEIA DO USUÁRIO

